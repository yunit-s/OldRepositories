package my.spring.springweb.sample06.vo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Lotto {

	private int lottoNum;
	private String result;
}
